import asyncio

async def main():
    # Worker loop will be connected to BinaryOptionsTools-v2/PyStrategy
    # after the API deployment is validated.
    while True:
        await asyncio.sleep(60)

if __name__ == "__main__":
    asyncio.run(main())

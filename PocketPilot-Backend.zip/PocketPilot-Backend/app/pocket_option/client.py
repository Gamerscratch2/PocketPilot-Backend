from app.config import settings

class PocketOptionClient:
    """Placeholder for the BinaryOptionsTools-v2 Pocket Option client.

    The real connection is deliberately added only after the DEMO-only
    safety checks and configuration have been validated.
    """

    def __init__(self):
        if not settings.demo_only:
            raise RuntimeError("PocketPilot is DEMO ONLY.")
        self.connected = False

    async def connect(self):
        if not settings.demo_only:
            raise RuntimeError("Live trading is disabled.")
        # BinaryOptionsTools-v2 integration will be added here.
        self.connected = True

    async def disconnect(self):
        self.connected = False

from typing import Any

class MarketDataManager:
    """Market-data abstraction.

    BinaryOptionsTools-v2 candle streaming will be connected here after
    the base Railway deployment is validated.
    """

    async def get_candles(self, asset: str, period: int) -> list[dict[str, Any]]:
        return []

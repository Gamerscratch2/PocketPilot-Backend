class RiskEngine:
    """Risk-management veto layer.

    The intended default is fail-safe: if required information is missing,
    the engine returns a NO_TRADE decision.
    """

    async def approve(self, signal: dict) -> dict:
        return {
            "approved": False,
            "reason": "Risk engine not configured yet",
        }
